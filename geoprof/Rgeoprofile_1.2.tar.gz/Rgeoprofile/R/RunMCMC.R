RunMCMC <-
function () 
{
    cat("Integrating over prior on concentration parameter alpha\n")
    flush.console()
    integrated_prob = rep(0, n)
    for (i in 1:n) {
        if (floor(i/10) == (i/10)) {
            cat(paste(i, "of", n, "\n"))
            flush.console()
        }
        temp = rep(0, 1001)
        for (j in 2:1001) {
            integrand = function(x) {
                exp((j - 501) * log(10) + i * log(x * n) + lgamma(x * 
                  n) - lgamma(n + x * n) - 2 * log(1 + x * n))
            }
            temp[j] = integrate(integrand, lower = 0, upper = Inf)$value * 
                n
            if (temp[j] < 0) 
                temp[j] = 0
            temp[j] = log(temp[j]) - (j - 501) * log(10)
            if (temp[j] != -Inf & abs(temp[j] - temp[j - 1]) < 
                1e-04) {
                integrated_prob[i] = temp[j]
                (break)()
            }
        }
    }
    mux_burnin = list()
    muy_burnin = list()
    group_burnin = list()
    frequencies_burnin = list()
    sumdatax_burnin = list()
    sumdatay_burnin = list()
    convergence = list()
    for (chain in 1:chains) {
        mux_burnin[[chain]] = matrix(0, nrow = maxburnin, ncol = n)
        mux_burnin[[chain]][1, ] = rnorm(n, sd = 100)
        muy_burnin[[chain]] = matrix(0, nrow = maxburnin, ncol = n)
        muy_burnin[[chain]][1, ] = rnorm(n, sd = 100)
        group_burnin[[chain]] = matrix(1, nrow = maxburnin, ncol = n)
        frequencies_burnin[[chain]] = matrix(0, nrow = maxburnin, 
            ncol = n)
        frequencies_burnin[[chain]][1, 1] = n
        sumdatax_burnin[[chain]] = matrix(0, nrow = maxburnin, 
            ncol = n)
        sumdatax_burnin[[chain]][1, 1] = sum(datax)
        sumdatay_burnin[[chain]] = matrix(0, nrow = maxburnin, 
            ncol = n)
        sumdatay_burnin[[chain]][1, 1] = sum(datay)
        thisloglike = 0
        currentgroups = unique(group_burnin[[chain]][1, ])
        for (j in currentgroups) {
            thisloglike = thisloglike + loglike(x = datax[group_burnin[[chain]][1, 
                ] == j], sigma = sigma, phi = priorx, tau = tau) + 
                loglike(x = datay[group_burnin[[chain]][1, ] == 
                  j], sigma = sigma, phi = priory, tau = tau)
        }
        thisloglike = thisloglike + integrated_prob[length(currentgroups)] + 
            sum(lgamma(frequencies_burnin[[chain]][1, currentgroups]))
        convergence[[chain]] = thisloglike
    }
    par(mfrow = c(1, 1))
    cat("Running burn-in\n")
    flush.console()
    for (i in 2:maxburnin) {
        for (chain in 1:chains) {
            mux_burnin[[chain]][i, ] = mux_burnin[[chain]][i - 
                1, ]
            muy_burnin[[chain]][i, ] = muy_burnin[[chain]][i - 
                1, ]
            group_burnin[[chain]][i, ] = group_burnin[[chain]][i - 
                1, ]
            frequencies_burnin[[chain]][i, ] = frequencies_burnin[[chain]][i - 
                1, ]
            sumdatax_burnin[[chain]][i, ] = sumdatax_burnin[[chain]][i - 
                1, ]
            sumdatay_burnin[[chain]][i, ] = sumdatay_burnin[[chain]][i - 
                1, ]
            for (j in 1:n) {
                frequencies_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] = frequencies_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] - 1
                sumdatax_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] = sumdatax_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] - datax[j]
                sumdatay_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] = sumdatay_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] - datay[j]
                postvar = 1/(frequencies_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]]/sigma^2 + 1/tau^2)
                postmeanx = (sumdatax_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]]/sigma^2 + priorx/tau^2) * postvar
                postmeany = (sumdatay_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]]/sigma^2 + priory/tau^2) * postvar
                mux_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] = rnorm(1, mean = postmeanx, sd = sqrt(postvar))
                muy_burnin[[chain]][i, group_burnin[[chain]][i, 
                  j]] = rnorm(1, mean = postmeany, sd = sqrt(postvar))
                probvec = log(frequencies_burnin[[chain]][i, 
                  ])
                probvec = probvec + dnorm(datax[j], mean = mux_burnin[[chain]][i, 
                  ], sd = sigma, log = T) + dnorm(datay[j], mean = muy_burnin[[chain]][i, 
                  ], sd = sigma, log = T)
                nextgroup = which(frequencies_burnin[[chain]][i, 
                  ] == 0)[1]
                probvec[nextgroup] = integrated_prob[sum(frequencies_burnin[[chain]][i, 
                  ] > 0) + 1] - integrated_prob[sum(frequencies_burnin[[chain]][i, 
                  ] > 0)]
                probvec[nextgroup] = probvec[nextgroup] + dnorm(datax[j], 
                  mean = priorx, sd = sqrt(sigma^2 + tau^2), 
                  log = T) + dnorm(datay[j], mean = priory, sd = sqrt(sigma^2 + 
                  tau^2), log = T)
                probvec = exp(probvec - max(probvec))
                newgroup = sample(n, 1, prob = probvec)
                group_burnin[[chain]][i, j] = newgroup
                frequencies_burnin[[chain]][i, newgroup] = frequencies_burnin[[chain]][i, 
                  newgroup] + 1
                sumdatax_burnin[[chain]][i, newgroup] = sumdatax_burnin[[chain]][i, 
                  newgroup] + datax[j]
                sumdatay_burnin[[chain]][i, newgroup] = sumdatay_burnin[[chain]][i, 
                  newgroup] + datay[j]
                if (newgroup == nextgroup) {
                  postvar = 1/(frequencies_burnin[[chain]][i, 
                    group_burnin[[chain]][i, j]]/sigma^2 + 1/tau^2)
                  postmeanx = (sumdatax_burnin[[chain]][i, group_burnin[[chain]][i, 
                    j]]/sigma^2 + priorx/tau^2) * postvar
                  postmeany = (sumdatay_burnin[[chain]][i, group_burnin[[chain]][i, 
                    j]]/sigma^2 + priory/tau^2) * postvar
                  mux_burnin[[chain]][i, group_burnin[[chain]][i, 
                    j]] = rnorm(1, mean = postmeanx, sd = sqrt(postvar))
                  muy_burnin[[chain]][i, group_burnin[[chain]][i, 
                    j]] = rnorm(1, mean = postmeany, sd = sqrt(postvar))
                }
            }
            thisloglike = 0
            currentgroups = unique(group_burnin[[chain]][i, ])
            for (j in currentgroups) {
                thisloglike = thisloglike + loglike(x = datax[group_burnin[[chain]][i, 
                  ] == j], sigma = sigma, phi = priorx, tau = tau) + 
                  loglike(x = datay[group_burnin[[chain]][i, 
                    ] == j], sigma = sigma, phi = priory, tau = tau)
            }
            thisloglike = thisloglike + integrated_prob[length(currentgroups)] + 
                sum(lgamma(frequencies_burnin[[chain]][i, currentgroups]))
            convergence[[chain]] = mcmc(c(convergence[[chain]], 
                thisloglike))
        }
        if (floor(i/10) == (i/10) & i > 50) {
            gelman.plot(convergence)
            abline(h = 1.1, lty = 3)
            if (gelman.diag(convergence)$psrf[2] < 1.1 & i > 
                minburnin) 
                break
        }
    }
    mux = matrix(0, nrow = Samples, ncol = n)
    mux[1, ] = mux_burnin[[1]][i, ]
    muy = matrix(0, nrow = Samples, ncol = n)
    muy[1, ] = muy_burnin[[1]][i, ]
    group = matrix(0, nrow = Samples, ncol = n)
    group[1, ] = group_burnin[[1]][i, ]
    frequencies = matrix(0, nrow = Samples, ncol = n)
    frequencies[1, ] = frequencies_burnin[[1]][i, ]
    sumdatax = matrix(0, nrow = Samples, ncol = n)
    sumdatax[1, ] = sumdatax_burnin[[1]][i, ]
    sumdatay = matrix(0, nrow = Samples, ncol = n)
    sumdatay[1, ] = sumdatay_burnin[[1]][i, ]
    loglike_store = rep(0, Samples)
    loglike_store[1] = convergence[[1]][i]
    cat("Obtaining samples\n")
    flush.console()
    for (i in 2:Samples) {
        if (floor(i/10) == (i/10)) {
            cat(paste(i, "of", Samples, "\n"))
            flush.console()
        }
        mux[i, ] = mux[i - 1, ]
        muy[i, ] = muy[i - 1, ]
        group[i, ] = group[i - 1, ]
        frequencies[i, ] = frequencies[i - 1, ]
        sumdatax[i, ] = sumdatax[i - 1, ]
        sumdatay[i, ] = sumdatay[i - 1, ]
        for (j in 1:n) {
            frequencies[i, group[i, j]] = frequencies[i, group[i, 
                j]] - 1
            sumdatax[i, group[i, j]] = sumdatax[i, group[i, j]] - 
                datax[j]
            sumdatay[i, group[i, j]] = sumdatay[i, group[i, j]] - 
                datay[j]
            postvar = 1/(frequencies[i, group[i, j]]/sigma^2 + 
                1/tau^2)
            postmeanx = (sumdatax[i, group[i, j]]/sigma^2 + priorx/tau^2) * 
                postvar
            postmeany = (sumdatay[i, group[i, j]]/sigma^2 + priory/tau^2) * 
                postvar
            mux[i, group[i, j]] = rnorm(1, mean = postmeanx, 
                sd = sqrt(postvar))
            muy[i, group[i, j]] = rnorm(1, mean = postmeany, 
                sd = sqrt(postvar))
            probvec = log(frequencies[i, ])
            probvec = probvec + dnorm(datax[j], mean = mux[i, 
                ], sd = sigma, log = T) + dnorm(datay[j], mean = muy[i, 
                ], sd = sigma, log = T)
            nextgroup = which(frequencies[i, ] == 0)[1]
            probvec[nextgroup] = integrated_prob[sum(frequencies[i, 
                ] > 0) + 1] - integrated_prob[sum(frequencies[i, 
                ] > 0)]
            probvec[nextgroup] = probvec[nextgroup] + dnorm(datax[j], 
                mean = priorx, sd = sqrt(sigma^2 + tau^2), log = T) + 
                dnorm(datay[j], mean = priory, sd = sqrt(sigma^2 + 
                  tau^2), log = T)
            probvec = exp(probvec - max(probvec))
            newgroup = sample(n, 1, prob = probvec)
            group[i, j] = newgroup
            frequencies[i, newgroup] = frequencies[i, newgroup] + 
                1
            sumdatax[i, newgroup] = sumdatax[i, newgroup] + datax[j]
            sumdatay[i, newgroup] = sumdatay[i, newgroup] + datay[j]
            if (newgroup == nextgroup) {
                postvar = 1/(frequencies[i, group[i, j]]/sigma^2 + 
                  1/tau^2)
                postmeanx = (sumdatax[i, group[i, j]]/sigma^2 + 
                  priorx/tau^2) * postvar
                postmeany = (sumdatay[i, group[i, j]]/sigma^2 + 
                  priory/tau^2) * postvar
                mux[i, group[i, j]] = rnorm(1, mean = postmeanx, 
                  sd = sqrt(postvar))
                muy[i, group[i, j]] = rnorm(1, mean = postmeany, 
                  sd = sqrt(postvar))
            }
        }
        thisloglike = 0
        currentgroups = unique(group[i, ])
        for (j in currentgroups) {
            thisloglike = thisloglike + loglike(x = datax[group[i, 
                ] == j], sigma = sigma, phi = priorx, tau = tau) + 
                loglike(x = datay[group[i, ] == j], sigma = sigma, 
                  phi = priory, tau = tau)
        }
        thisloglike = thisloglike + integrated_prob[length(currentgroups)] + 
            sum(lgamma(frequencies[i, currentgroups]))
        loglike_store[i] = thisloglike
        if (floor(i/100) == (i/100)) {
            plot(datax, datay, pch = 20, xlim = c(xmin, xmax), 
                ylim = c(ymin, ymax), col = MCMCcols2[group[i, 
                  ]], main = paste("Sample:", i))
        }
    }
    par(mfrow = c(1, 2))
    autocorr.plot(loglike_store, auto.layout = F, lag.max = Samples)
    groupnum = rowSums(frequencies > 0)
    realised_sources = hist(groupnum, breaks = 0:n, plot = F)$density
    realised_sources_nonzero = min(which(realised_sources != 
        0)):max(which(realised_sources != 0))
    barplot(realised_sources[realised_sources_nonzero], names.arg = realised_sources_nonzero, 
        space = 0, xlab = "Realised Sources", ylab = "Probability")
    Group <<- group
    Frequencies <<- frequencies
    Sumdatax <<- sumdatax
    Sumdatay <<- sumdatay
}
