GraphicParameters <-
function (Guardrail = 0.05, nring = 20, transp = 0.4, gridsize = 640, 
    gridsize2 = 300, MapType = "roadmap", Location = getwd(), 
    pointcol = "black") 
{
    Guardrail <<- Guardrail
    nring <<- nring
    transp <<- transp
    gridsize <<- gridsize
    gridsize2 <<- gridsize2
    MapType <<- MapType
    Location <<- Location
    pointcol <<- pointcol
    cat("Graphic parameters loaded as global variables\n")
}
