ModelParameters <-
function (sigma = 1, tau = "DEFAULT", minburnin = 100, maxburnin = 1000, 
    chains = 5, Samples = 10000) 
{
    sigma <<- sigma
    tau <<- tau
    minburnin <<- minburnin
    maxburnin <<- maxburnin
    chains <<- chains
    Samples <<- Samples
    cat("Model parameters loaded as global variables\n")
}
